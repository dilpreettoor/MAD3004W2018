//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
print(str)
//use terminoator for terminating \n
print("This is our String: \(str)",terminator: " ")
//use separator for sperating multiple prompts
print("1","2","3","4","5",separator: "\n")

var n1 = 10;
print("Numbner 1: ",n1,"String :",str)

var n2 = 20;
print("Number 2: " ,n2)

var sum = n1 + n2
print("Sum is : ",sum)
print("Sum = ", n1+n2)
/*
n1 = "test"
print("n1 : ",n1)
 the above code wont work because swift automatically made n1 (int) when it was first declared
*/
var a:Int = 10;
print("a = ",a)

var greet:String = "Good Morning"
print("Greeting : ",greet)
var pii:Float = 22/7
print("Pii : ",pii )
//use ctrl+win(command)+space for emoji
print("🥧",terminator: " ")
let pi = 3.14;
// can assign value to constant pi = 3.190;
print ("Pi = ",pi )
let myNum: Int? //optional
myNum = nil
if myNum != nil {
    print("myNum: ",myNum!)
}
else{
    print("myNum is Nil")
}

let possibleNumber = "Hello"
let convertedNumber:Int?

convertedNumber = Int(possibleNumber)
if convertedNumber != nil {
    print("Converted Number" ,convertedNumber!)

}
else{
    print("Converted Number is nil")
}

for i in 1...5{ //for loop
print ("i = ",i)
}

for i in 1..<5{ //for loop when using great/less
    print ("i = ",i)
}

let language:[String]
language = ["Punjabi","English","Spanish","French"]

for i in language {
    print("language: ",i)
}

var answer: Int = 1

for _ in 1...5{
    answer += 5;
}
print("answer", answer)
var j = 1;
while (j<5) {
    print("Value of j is \(j)")
    j=j+1
}

j = 5
repeat{
    print("Repeat :",j)
    j=j+2
}while (j<=10)

var input = 11

if input < 10 {
    for i in 1...10 {
        print (5 ," *",i," =",i*5)
    }
   
}
else{
    var number : Int = 5
    var fact: Int = 1
    var n: Int = number + 1
    for i in 1..<n
    {
    fact = fact * i;
    }
    print(fact)
    }











